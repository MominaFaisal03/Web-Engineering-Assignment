//text animation
const changingLetter = document.getElementById('changing-letter');
const letters = ["CODER", "PROGRAMMER", "DESIGNER", "DEVELOPER"];
let index = 0;

setInterval(() => {
    index = (index + 1) % letters.length;
    changingLetter.textContent = letters[index];
}, 1000);

document.getElementById('watchVideo').addEventListener('click', () => {
    document.getElementById('videoPopup').classList.remove('hidden');
    document.querySelector('#videoPopup iframe').src = "https://www.youtube.com/watch?v=sPsW47LO9MA";
});

document.getElementById('closeVideo').addEventListener('click', () => {
    document.getElementById('videoPopup').classList.add('hidden');
    document.querySelector('#videoPopup iframe').src = ""; 
});

// Hexagon
const hexagonPolygon = document.querySelector('#hexagon-svg polygon');
const animatedImage = document.getElementById('animated-image');

let translateY = 0;
let direction = 1;

function animateBorder() {
    translateY += direction;
    const newPoints = `${100},${30 + translateY} ${160},${70 + translateY} ${160},${130 + translateY} 
    ${100},${170 + translateY} ${40},${130 + translateY} ${40},${70 + translateY}`;
 
    hexagonPolygon.setAttribute('points', newPoints);
    animatedImage.setAttribute('y', 30 + translateY);
    if (translateY <= 0 || translateY >= 50) {
        direction *= -1;
    }
    requestAnimationFrame(animateBorder);
}
animateBorder();
 
// Counter
document.addEventListener('scroll', function () {
    const aboutMeSection = document.getElementById('about-me');
    const offset = aboutMeSection.offsetTop;
    const windowHeight = window.innerHeight;
    const scrollPosition = window.scrollY;

    if (scrollPosition > offset - windowHeight * 0.8) {

        counterUp('projectCounter', 0, 724, 10, 24); 
        counterUp('reviewCounter', 0, 508, 10, 24);

        document.removeEventListener('scroll', this);
    }
});

function counterUp(elementId, start, end, duration, fontSize) {
    const element = document.getElementById(elementId);
    const range = end - start;
    const increment = end > start ? 1 : -1;
    const stepTime = Math.abs(Math.floor(duration / range));

    element.style.fontSize = `${fontSize}px`;

    function updateCounter() {
        start += increment;
        element.innerText = start;

        if ((increment > 0 && start < end) || (increment < 0 && start > end)) {
            setTimeout(updateCounter, stepTime);
        }
    }

    updateCounter();
}
